<?php
echo (pi()); // returns 3.1415926535898
