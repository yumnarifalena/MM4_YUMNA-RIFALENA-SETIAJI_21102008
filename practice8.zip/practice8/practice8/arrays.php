<?php
$cars = array("Volvo", "BMW", "Toyota");
echo count($cars);
