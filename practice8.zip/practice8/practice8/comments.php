<!DOCTYPE html>
<html>

<body>

    <h2>Comment in PHP:</h2>
    <p>
        // This is a single-line comment
        <br>
        # This is also a single-line comment
    </p>

    <?php
    // This is a single-line comment

    # This is also a single-line comment
    ?>

</body>

</html>