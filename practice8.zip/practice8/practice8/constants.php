<?php
define("GREETING", "Welcome to W3Schools.com!");
echo GREETING;
